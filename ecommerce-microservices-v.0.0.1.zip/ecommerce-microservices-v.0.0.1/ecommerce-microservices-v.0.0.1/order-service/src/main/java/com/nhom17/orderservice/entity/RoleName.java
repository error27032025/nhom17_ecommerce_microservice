package com.nhom17.orderservice.entity;

public enum  RoleName {
    USER, PM, ADMIN
}
