package com.nhom17.productservice.repository;

import com.nhom17.productservice.entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CategoryRepository extends JpaRepository<Category, Integer> {

    Page<Category> findAll(Pageable pageable);

    // Thêm các phương thức tìm kiếm hoặc lọc tại đây
    Page<Category> findByCategoryTitleContaining(String categoryTitle, Pageable pageable);

}
