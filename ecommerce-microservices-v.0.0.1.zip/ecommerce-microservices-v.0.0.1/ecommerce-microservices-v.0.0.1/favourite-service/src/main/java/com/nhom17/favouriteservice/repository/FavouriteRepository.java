package com.nhom17.favouriteservice.repository;

import com.nhom17.favouriteservice.entity.Favourite;
import com.nhom17.favouriteservice.entity.id.FavouriteId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FavouriteRepository extends JpaRepository<Favourite, FavouriteId> {

}
