package com.nhom17.shippingservice.repository;

import com.nhom17.shippingservice.domain.OrderItem;
import com.nhom17.shippingservice.domain.id.OrderItemId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderItemRepository extends JpaRepository<OrderItem, OrderItemId> {

}