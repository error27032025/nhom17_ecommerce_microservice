package com.nhom17.proxyclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProxyClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
